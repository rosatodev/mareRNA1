var text_enviado = document.getElementById("text_enviado");
var input_text;
var btn_enviar = document.getElementById("btn_enviar");

var slideIndex = 0;
showAutoSlides();


function showAutoSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}

    //for (i = 0; i < dots.length; i++) {
        //dots[i].className = dots[i].className.replace(" active", "");
    //}
    // dots[slideIndex-1].className += " active";
    
    slides[slideIndex-1].style.display = "block";

    setTimeout(showAutoSlides, 10000); // Cambio de imagen
}
showSlides(slideIndex);

// Siguiente/Anterior controles
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail control de imagenes
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  //var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }

  
  //for (i = 0; i < dots.length; i++) {
   //   dots[i].className = dots[i].className.replace(" active", "");
  //}
  
  slides[slideIndex-1].style.display = "block";
  //dots[slideIndex-1].className += " active";
  
}

btn_enviar.onclick = function(){
    // OBTENER VALOR
    input_text = document.getElementById("input_text").value;

    // CAMBIAR VALOR
    text_enviado.innerHTML = input_text;
};