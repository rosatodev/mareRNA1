
var btn_home = document.getElementById("btn_home");
var btn_news = document.getElementById("btn_news");
var btn_sports = document.getElementById("btn_sports");
var btn_menu = document.getElementById("btn_menu");


btn_home.onclick = function(){
    homeActivity();
};

btn_news.onclick = function(){
    newsActivity();
};

btn_sports.onclick = function(){
    sportsActivity();

};

btn_menu.onclick = function(){
    menuActivity();
};

function homeActivity (){
    alert("Tocaste HOME");
}

function newsActivity (){
    alert("Tocaste NOTICIAS");
}

function sportsActivity (){
    alert("Tocaste DEPORTES");

}

function menuActivity (){
    alert("Tocaste MENU");

}